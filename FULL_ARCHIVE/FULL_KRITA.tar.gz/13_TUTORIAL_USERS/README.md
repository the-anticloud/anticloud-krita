# 13 Tutorial Users

**Project:** KRITA
**Upstream:** https://github.com/krita/krita

Content specific to KRITA in category ARTIST_TOOLS.
